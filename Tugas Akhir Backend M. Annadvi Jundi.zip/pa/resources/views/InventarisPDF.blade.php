<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PDF Inventaris</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            border: 1px solid #e2e8f0;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f8fafc;
        }
    </style>
</head>

<body>
    <h1>Inventaris Barang</h1>
    <p>{{ $date }}</p>
    <table>
            <tr>
                <th>No</th>
                <th>Inventaris</th>
                <th>Kondisi</th>
                <th>Harga</th>
                <th>Jumlah</th>
                <th>Kategori</th>
            </tr>
            @php
                $no = 1;
            @endphp
            @foreach ($inventaris as $inv)
            <tr>
                <td>{{ $no++ }}</td>
                <td>{{ $inv->nama_barang }}</td>
                <td>{{ $inv->kondisi }}</td>
                <td>{{ $inv->harga }}</td>
                <td>{{ $inv->jumlah }}</td>
                <td>{{ $inv->kategori->nama }}</td>
            </tr>
            @endforeach
    </table>
</body>

</html>
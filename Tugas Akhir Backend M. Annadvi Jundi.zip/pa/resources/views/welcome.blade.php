<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="font-light antialiased">
    <header class="flex items-center justify-between py-3 px-6 border-b border-gray-100">
        <div id="header-left" class="flex items-center">
            <div class="text-gray-800 font-semibold">
                <span class="text-blue-500 text-xl">Inventaris</span>
            </div>
            <div class="top-menu ml-10">
                <ul class="flex space-x-4">
                    <li>
                        <a class="flex space-x-2 items-center hover:text-blue-900 text-sm text-blue-500"
                            href="http://127.0.0.1:8000">
                            Home
                        </a>
                    </li>

                    <li>
                        <a class="flex space-x-2 items-center hover:text-blue-500 text-sm text-gray-500"
                            href="http://127.0.0.1:8000/blog">
                            Blog
                        </a>
                    </li>

                    <li>
                        <a class="flex space-x-2 items-center hover:text-blue-500 text-sm text-gray-500"
                            href="http://127.0.0.1:8000/blog">
                            About Us
                        </a>
                    </li>

                    <li>
                        <a class="flex space-x-2 items-center hover:text-blue-500 text-sm text-gray-500"
                            href="http://127.0.0.1:8000/blog">
                            Contact Us
                        </a>
                    </li>

                    <li>
                        <a class="flex space-x-2 items-center hover:text-blue-500 text-sm text-gray-500"
                            href="http://127.0.0.1:8000/blog">
                            Terms
                        </a>
                    </li>

                </ul>
            </div>
        </div>
        <div id="header-right" class="flex items-center md:space-x-6">
            <div class="flex space-x-5">
                <a class="flex space-x-2 items-center hover:text-blue-500 text-sm text-gray-500"
                    href="http://127.0.0.1:8000/admin/login">
                    Login
                </a>
            </div>
        </div>
    </header>

    <div class="hero-section bg-gray-800 text-white py-20 px-6">
        <div class="container mx-auto text-center">
            <h1 class="text-4xl font-bold mb-4">Welcome to Inventaris</h1>
            <p class="text-lg mb-8">Your destination for high-quality inventory management resources</p>
            <a href="#" class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded">Get Started</a>
        </div>
    </div>

    <footer class="bg-gray-900 text-white py-6 px-6">
        <div class="container mx-auto text-center">
            <p>&copy; 2024 Inventaris. All rights reserved.</p>
        </div>
    </footer>
    
</body>
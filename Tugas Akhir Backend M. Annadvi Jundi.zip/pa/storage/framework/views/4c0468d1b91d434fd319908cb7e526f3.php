<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PDF BARANG</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            border: 1px solid #e2e8f0;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f8fafc;
        }
    </style>
</head>

<body>
    <h1>Kategori Barang</h1>
    <p><?php echo e($date); ?></p>
    <table>
            <tr>
                <th>No</th>
                <th>Nama Kategori</th>
            </tr>
            <?php
                $no = 1;
            ?>
            <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ktgr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($ktgr->nama); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>

</html><?php /**PATH C:\xampp\htdocs\baru lagi\pa (2)\pa\resources\views/kategoriPDF.blade.php ENDPATH**/ ?>
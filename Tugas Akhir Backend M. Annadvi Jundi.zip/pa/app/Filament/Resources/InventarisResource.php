<?php

namespace App\Filament\Resources;

use Filament\Forms;
use Filament\Tables;
use Filament\Forms\Form;
use App\Models\Inventaris;
use Filament\Tables\Table;
use Filament\Infolists\Infolist;
use Filament\Resources\Resource;
use Filament\Forms\Components\Card;
use Filament\Forms\Components\Select;
use Filament\Infolists\Components\Section;
use Filament\Tables\Columns\TextColumn;
use Filament\Forms\Components\TextInput;
use Filament\Tables\Filters\SelectFilter;
use Illuminate\Database\Eloquent\Builder;
use Filament\Infolists\Components\TextEntry;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use App\Filament\Resources\InventarisResource\Pages;
use App\Filament\Resources\InventarisResource\RelationManagers;

class InventarisResource extends Resource
{
    protected static ?string $model = Inventaris::class;

    protected static ?string $recordTitleAttribute = 'nama_barang';

    protected static ?string $navigationGroup = 'Inventaris';

    protected static ?string $navigationIcon = 'heroicon-o-clipboard-document-list';

    public static function form(Form $form): Form
    {
        return $form
        ->schema([
            Card::make()
            ->schema([
                TextInput::make('nama_barang')->placeholder('Masukkan Nama Barang'),
                TextInput::make('jumlah'),
                TextInput::make('harga'),
                TextInput::make('kondisi'),
                Select::make('kategori_id')
                ->relationship('kategori', 'nama')
                    ->createOptionForm([
                        Forms\Components\TextInput::make('nama')->required(),
                    ]),
            ]),
        ]);
    }

        public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('id'),
                TextColumn::make('nama_barang')->limit('45')->searchable()->sortable(),
                TextColumn::make('kategori.nama'),
            ])
            ->filters([
                SelectFilter::make('kategori')
                    ->options(function () {
                        return \App\Models\Kategori::pluck('nama', 'id')->toArray();
                    })
                    ->searchable()
                    ->relationship('kategori', 'nama')
            ])
            ->actions([
                Tables\Actions\ViewAction::make(),
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function infolist(Infolist $infolist): Infolist
    {
        return $infolist
            ->schema([
                Section::make('Inventaris Info')
                    ->schema([
                        TextEntry::make('nama_barang')->label('Nama Barang'),
                        TextEntry::make('kondisi')->label('Kondisi'),
                        TextEntry::make('harga')->label('Harga'),
                        TextEntry::make('jumlah')->label('Jumlah'),
                        TextEntry::make('kategori.nama')->label('Kategori'),
                    ])->columns(2)
            ]);
    }


    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListInventaris::route('/'),
            'create' => Pages\CreateInventaris::route('/create'),
            //'view' => Pages\ViewInventaris::route('/{record}'),
            'edit' => Pages\EditInventaris::route('/{record}/edit'),
        ];
    }
}

<?php

namespace App\Filament\Resources;

use Filament\Forms;
use Filament\Tables;
use App\Models\Gedung;
use Filament\Forms\Form;
use Filament\Tables\Table;
use Filament\Infolists\Infolist;
use Filament\Resources\Resource;
use Filament\Forms\Components\Card;
use Filament\Forms\Components\Select;
use Filament\Tables\Columns\TextColumn;
use Filament\Forms\Components\TextInput;
use Illuminate\Database\Eloquent\Builder;
use Filament\Infolists\Components\Section;
use Filament\Infolists\Components\TextEntry;
use App\Filament\Resources\GedungResource\Pages;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use pxlrbt\FilamentExcel\Actions\Tables\ExportBulkAction;
use App\Filament\Resources\GedungResource\RelationManagers;

class GedungResource extends Resource
{
    protected static ?string $model = Gedung::class;

    protected static ?string $recordTitleAttribute = 'nama';

    protected static ?string $navigationGroup = 'Inventaris';

    protected static ?string $navigationIcon = 'heroicon-o-building-office-2';

    public static function form(Form $form): Form
    {
        return $form
        ->schema([
            Card::make()
            ->schema([
                TextInput::make('nama')->placeholder('Masukkan Nama Gedung'),
                TextInput::make('jumlah'),
                Select::make('inventaris_id')
                ->label('Nama Barang')
                ->relationship('inventaris', 'nama_barang')
                    ->createOptionForm([
                        Forms\Components\TextInput::make('nama_barang')->required(),
                    ]),
                Select::make('inventaris_kategori_id')
                ->label('Nama Kategori')
                ->relationship('kategori', 'nama')
                    ->createOptionForm([
                        Forms\Components\TextInput::make('nama')->required(),
                    ]),
            ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('id'),
                TextColumn::make('nama')->limit('45')->searchable()->sortable(),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\ViewAction::make(),
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function infolist(Infolist $infolist): infolist
    {
        return $infolist
        ->schema([
            Section::make('Gedung Info')
            ->schema([
                TextEntry::make('nama')->label('Nama Gedung'),
                TextEntry::make('inventaris.nama_barang')->label('Nama Barang'),
                TextEntry::make('kategori.nama')->label('Kategori'),
                TextEntry::make('jumlah')->label('Jumlah Barang'),
            ])->columns(2)
        ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListGedungs::route('/'),
            'create' => Pages\CreateGedung::route('/create'),
            //'view' => Pages\ViewInventaris::route('/{record}'),
            'edit' => Pages\EditGedung::route('/{record}/edit'),
        ];
    }
}

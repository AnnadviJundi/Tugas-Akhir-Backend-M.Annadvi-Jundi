<?php

namespace App\Filament\Resources\KategoriResource\Pages;

use Filament\Actions;

use pxlrbt\FilamentExcel\Columns\Column;
use Filament\Resources\Pages\ListRecords;
use App\Filament\Resources\KategoriResource;
use pxlrbt\FilamentExcel\Exports\ExcelExport;
use pxlrbt\FilamentExcel\Actions\Pages\ExportAction;

class ListKategoris extends ListRecords
{
    protected static string $resource = KategoriResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
            Actions\PdfAction::make('Export Pdf')
            ->url(fn()=>route('download.pdf'))
                ->icon('heroicon-o-document')
                ->openUrlInNewTab(),

            ExportAction::make()
                ->label('Export Excel')
                ->icon('heroicon-o-document')
                ->exports([
                    ExcelExport::make()->withColumns([
                        Column::make('id')->heading('No'),
                        Column::make('nama')->heading('Kategori'),
                    ]),
                ]),


        ];
    }
}

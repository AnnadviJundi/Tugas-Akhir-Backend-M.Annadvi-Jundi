<?php

namespace App\Http\Controllers;

use App\Models\Gedung;
use Illuminate\Http\Request;
use PDF;

class GedungPDFController extends Controller
{
    public function downloadpdf()
    {
        $gedung = Gedung::all();

        $data = [
            'date' => date('m/d/Y'),
            'gedung' => $gedung,
        ];

        $pdf = PDF::loadView('gedungPDF', $data);
        return $pdf->download('Gedung.pdf');
    }
}

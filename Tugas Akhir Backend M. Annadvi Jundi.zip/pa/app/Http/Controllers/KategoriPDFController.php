<?php

namespace App\Http\Controllers;

use PDF;
use App\Models\Kategori;
use Illuminate\Http\Request;

class KategoriPDFController extends Controller
{
    public function downloadpdf()
    {
        $kategori = Kategori::all();

        $data = [
            'date' => date('m/d/Y'),
            'kategori' => $kategori,
        ];

        $pdf = PDF::loadView('kategoriPDF', $data);
        return $pdf->download('Kategori.pdf');
    }
}

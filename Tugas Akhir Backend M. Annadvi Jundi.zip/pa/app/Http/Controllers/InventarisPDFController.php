<?php

namespace App\Http\Controllers;

use App\Models\Inventaris;
use Illuminate\Http\Request;
use PDF;

class InventarisPDFController extends Controller
{
    public function downloadpdf()
    {
        $inventaris = Inventaris::all();

        $data = [
            'date' => date('m/d/Y'),
            'inventaris' => $inventaris,
        ];

        $pdf = PDF::loadView('inventarisPDF', $data);
        return $pdf->download('Inventaris.pdf');
    }
}

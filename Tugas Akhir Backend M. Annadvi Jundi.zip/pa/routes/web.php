<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\GedungPDFController;
use App\Http\Controllers\KategoriPDFController;
use App\Http\Controllers\InventarisPDFController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('download', [KategoriPDFController::class, 'downloadpdf'])->name('download.pdf');

Route::get('download', [InventarisPDFController::class, 'downloadpdf'])->name('download.pdf');

Route::get('download', [GedungPDFController::class, 'downloadpdf'])->name('download.pdf');

